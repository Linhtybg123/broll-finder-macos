import os
import struct
from pathlib import Path
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
from PySide6.QtCore import QByteArray,QBuffer,QIODevice,QRectF,Qt
from PySide6.QtGui import QGuiApplication,QImage,QPainter
from PySide6.QtSvg import QSvgRenderer
app=QGuiApplication([])
root=Path(__file__).resolve().parent.parent
renderer=QSvgRenderer(str(root/'studio/assets/logo.svg'))
chunks=[]
for name,size in ((b'ic07',128),(b'ic08',256),(b'ic09',512),(b'ic10',1024)):
    raster=QImage(size,size,QImage.Format_ARGB32)
    raster.fill(Qt.transparent)
    painter=QPainter(raster)
    renderer.render(painter,QRectF(0,0,size,size))
    painter.end()
    data=QByteArray()
    buffer=QBuffer(data)
    buffer.open(QIODevice.WriteOnly)
    assert raster.save(buffer,'PNG')
    payload=bytes(data)
    chunks.append(name+struct.pack('>I',len(payload)+8)+payload)
payload=b''.join(chunks)
(root/'assets/AppIcon.icns').write_bytes(b'icns'+struct.pack('>I',len(payload)+8)+payload)
print('Created macOS icon, 128-1024 pixels.')
