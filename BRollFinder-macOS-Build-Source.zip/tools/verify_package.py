import ast
import hashlib
import json
import plistlib
import stat
import struct
import tarfile
import zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
archive=ROOT/'output/BRollFinder-Studio-macOS-AppleSilicon-UNTESTED.zip'
prefix='B-Roll Finder Studio.app/Contents/'
manifest=json.loads((ROOT/'engine-manifest.json').read_text())
report={}
with zipfile.ZipFile(archive) as z:
    info=plistlib.loads(z.read(prefix+'Info.plist'))
    assert info['LSMinimumSystemVersion']=='14.0'
    executable=z.getinfo(prefix+'MacOS/'+info['CFBundleExecutable'])
    assert executable.external_attr>>16 & 0o111
    assert z.read(executable).startswith(b'#!/bin/bash\n')
    assert prefix+'Resources/runtime/python/bin/python3.14' in z.namelist()
    assert prefix+'Resources/bin/deno' in z.namelist()
    icon=z.read(prefix+'Resources/AppIcon.icns')
    assert icon[:4]==b'icns' and struct.unpack('>I',icon[4:8])[0]==len(icon)
    for name,digest in manifest['modules'].items():
        path=prefix+'Resources/engine/'+name.replace('.','/')
        path=path+'.pyc' if path+'.pyc' in z.namelist() else path+'/__init__.pyc'
        data=z.read(path)
        assert data[:4].hex()==manifest['python_magic']
        assert hashlib.sha256(data[16:]).hexdigest()==digest,name
    # These are the actual imported packages, not merely their distribution metadata.
    site=prefix+'Resources/runtime/python/lib/python3.14/site-packages/'
    for module in ('PySide6/__init__.py','numpy/__init__.py','soundfile.py','requests/__init__.py',
                   'faster_whisper/__init__.py','yt_dlp/__init__.py','imageio_ffmpeg/__init__.py'):
        assert site+module in z.namelist(),module
    assert not any(name.lower().endswith(('.exe','.pyd','.dll')) for name in z.namelist())
    report['original_modules_verified']=len(manifest['modules'])
    report['symlinks_preserved']=sum(stat.S_ISLNK(i.external_attr>>16) for i in z.infolist())
    report['executable_permissions']=True
    report['mac_icon']=True
    report['windows_binaries']=0
for path in [*ROOT.glob('*.py'),*ROOT.glob('studio/*.py'),*ROOT.glob('tools/*.py')]:
    ast.parse(path.read_text(encoding='utf-8'),filename=str(path))
report['source_syntax']='PASS'
report['native_runtime_test']='NOT_RUN_NO_MACOS_HOST'
(ROOT/'qa/static-validation.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report,indent=2))
