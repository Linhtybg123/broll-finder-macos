import json
import marshal
import os
from pathlib import Path
root=Path(os.environ['STUDIO_BUILD_SCRIPT']).resolve().parent.parent
findings=[]
flags={'winreg','windll','startfile','STARTUPINFO','CREATE_NO_WINDOW','WinDLL','getwindowsversion'}
def scan(code,name):
    hits=flags.intersection(code.co_names)
    if hits:
        findings.append({'module':name,'function':code.co_name,'windows_names':sorted(hits),
                         'has_os_name_guard':'name' in code.co_names or 'platform' in code.co_names,
                         'strings':[s for s in code.co_consts if isinstance(s,str) and s in ('nt','win32','darwin')]})
    for child in code.co_consts:
        if hasattr(child,'co_code'):
            scan(child,name)
for file in (root/'engine').rglob('*.pyc'):
    scan(marshal.loads(file.read_bytes()[16:]),file.relative_to(root/'engine').as_posix())
(root/'qa/engine-platform-audit.json').write_text(json.dumps(findings,indent=2),encoding='utf-8')
print(json.dumps(findings,indent=2))
