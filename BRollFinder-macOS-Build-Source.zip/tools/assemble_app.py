"""Assemble a relocatable macOS .app ZIP without executing macOS binaries.

This is packaging + static verification, NOT a substitute for running test_macos.py.
ZIP entries preserve POSIX permissions and symlinks even when prepared on Windows.
"""
import hashlib
import io
import json
import plistlib
import stat
import struct
import tarfile
import zipfile
from pathlib import Path,PurePosixPath

ROOT=Path(__file__).resolve().parent.parent
APP='B-Roll Finder Studio.app'
PREFIX=APP+'/Contents/Resources/'
ARM64=0x0100000c

def architectures(data):
    magic=data[:4]
    if magic in (b'\xcf\xfa\xed\xfe',b'\xce\xfa\xed\xfe'):
        return [struct.unpack_from('<I',data,4)[0]]
    if magic in (b'\xfe\xed\xfa\xcf',b'\xfe\xed\xfa\xce'):
        return [struct.unpack_from('>I',data,4)[0]]
    if magic in (b'\xca\xfe\xba\xbe',b'\xca\xfe\xba\xbf'):
        stride=32 if magic[-1]==0xbf else 20
        return [struct.unpack_from('>I',data,8+i*stride)[0] for i in range(struct.unpack_from('>I',data,4)[0])]
    return []

def build():
    output=ROOT/'output'
    output.mkdir(exist_ok=True)
    target=output/'BRollFinder-Studio-macOS-AppleSilicon-UNTESTED.zip'
    names={}
    binaries=[]
    wheels=[]
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=5,allowZip64=True) as result:
        def add(path,data,mode=0o644,symlink=False):
            parts=PurePosixPath(path).parts
            if '..' in parts or PurePosixPath(path).is_absolute():
                raise ValueError('Unsafe archive path: '+path)
            if path in names:
                if names[path]==hashlib.sha256(data).hexdigest():
                    return
                raise ValueError('Conflicting bundle member: '+path)
            names[path]=hashlib.sha256(data).hexdigest()
            arch=[] if symlink else architectures(data)
            if arch:
                if ARM64 not in arch:
                    raise ValueError('Native library has no ARM64 slice: '+path)
                mode|=0o111
                binaries.append(path)
            entry=zipfile.ZipInfo(path,date_time=(2026,11,6,0,0,0))
            entry.create_system=3
            entry.compress_type=zipfile.ZIP_DEFLATED
            entry.external_attr=((stat.S_IFLNK if symlink else stat.S_IFREG)|mode)<<16
            result.writestr(entry,data,compresslevel=5)
        print('Packing Apple Silicon Python...',flush=True)
        with tarfile.open(ROOT/'downloads/python-arm64.tar.gz') as archive:
            for member in archive.getmembers():
                if member.isdir():
                    continue
                if PurePosixPath(member.name).suffix.lower() in ('.exe','.dll','.pyd'):
                    continue
                path=PREFIX+'runtime/'+member.name
                if member.issym():
                    add(path,member.linkname.encode(),0o777,True)
                else:
                    with archive.extractfile(member) as stream:
                        add(path,stream.read(),member.mode&0o777)
        print('Packing macOS dependency wheels...',flush=True)
        for wheel in sorted((ROOT/'downloads/wheels').glob('*.whl')):
            if wheel.name.startswith(('pyside6-','pyside6_pdf-','pyside6_webengine-')):
                continue
            wheels.append({'file':wheel.name,'sha256':hashlib.sha256(wheel.read_bytes()).hexdigest()})
            with zipfile.ZipFile(wheel) as archive:
                for member in archive.infolist():
                    if member.is_dir():
                        continue
                    path=PurePosixPath(member.filename)
                    if path.suffix.lower() in ('.exe','.dll','.pyd'):
                        continue
                    parts=path.parts
                    if parts[0].endswith('.data'):
                        section=parts[1]
                        if section in ('purelib','platlib'):
                            path=PurePosixPath(*parts[2:])
                        elif section=='scripts':
                            continue  # application uses module APIs, never console entry points
                        elif section=='data':
                            add(PREFIX+'runtime/python/'+str(PurePosixPath(*parts[2:])),archive.read(member))
                            continue
                        else:
                            continue
                    mode=(member.external_attr>>16)&0o777 or 0o644
                    link=stat.S_ISLNK(member.external_attr>>16)
                    add(PREFIX+'runtime/python/lib/python3.14/site-packages/'+str(path),archive.read(member),mode,link)
        for directory in ('engine','studio'):
            for path in sorted((ROOT/directory).rglob('*')):
                if path.is_file() and '__pycache__' not in path.parts:
                    add(PREFIX+path.relative_to(ROOT).as_posix(),path.read_bytes())
        for name in ('main_macos.py','engine-manifest.json'):
            add(PREFIX+name,(ROOT/name).read_bytes())
        with zipfile.ZipFile(ROOT/'downloads/deno-arm64.zip') as archive:
            add(PREFIX+'bin/deno',archive.read('deno'),0o755)
        launcher='''#!/bin/bash
set -e
CONTENTS="$(cd "$(dirname "$0")/.." && pwd)"
RESOURCES="$CONTENTS/Resources"
unset PYTHONHOME PYTHONPATH PYTHONSTARTUP
export PYTHONNOUSERSITE=1 PYTHONDONTWRITEBYTECODE=1
export PATH="$RESOURCES/bin:/usr/bin:/bin:/usr/sbin:/sbin"
exec "$RESOURCES/runtime/python/bin/python3.14" "$RESOURCES/main_macos.py" "$@"
'''
        add(APP+'/Contents/MacOS/BRollFinder',launcher.encode(),0o755)
        info={'CFBundleName':'B-Roll Finder Studio','CFBundleDisplayName':'B-Roll Finder Studio',
              'CFBundleIdentifier':'studio.brollfinder.macos','CFBundleVersion':'2.0.0','CFBundleShortVersionString':'2.0.0',
              'CFBundleExecutable':'BRollFinder','CFBundleIconFile':'AppIcon','CFBundlePackageType':'APPL',
              'LSMinimumSystemVersion':'14.0','NSHighResolutionCapable':True,'LSArchitecturePriority':['arm64'],
              'NSHumanReadableCopyright':'B-Roll Finder Studio; third-party licenses included in runtime packages.'}
        add(APP+'/Contents/Info.plist',plistlib.dumps(info))
        add(APP+'/Contents/PkgInfo',b'APPL????')
        add(PREFIX+'AppIcon.icns',(ROOT/'assets/AppIcon.icns').read_bytes())
    with zipfile.ZipFile(target) as result:
        assert result.testzip() is None
        assert APP+'/Contents/MacOS/BRollFinder' in result.namelist()
    report={'status':'ASSEMBLED_NOT_MACOS_TESTED','minimum_macos':'14.0','architecture':'arm64',
            'native_binaries_checked':len(binaries),'native_binaries':binaries,'wheels':wheels,
            'zip':target.name,'bytes':target.stat().st_size,'sha256':hashlib.sha256(target.read_bytes()).hexdigest()}
    (ROOT/'qa/assembly-report.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in report.items() if k not in ('native_binaries','wheels')},indent=2))

if __name__=='__main__':
    build()
