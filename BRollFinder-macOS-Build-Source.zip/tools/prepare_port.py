"""Copy only application bytecode and assets; never copy Windows dependencies."""
import hashlib
import json
import marshal
import shutil
import struct
import zlib
from pathlib import Path
from PyInstaller.archive.readers import CArchiveReader

root = Path(__file__).resolve().parent.parent
workspace = root.parent
source = Path(r'F:\BRollFinder_20261105\BRollFinder UP')
archive = CArchiveReader(str(source/'BRollFinder.exe'))
pyz = archive.extract('PYZ.pyz')
toc = dict(marshal.loads(pyz[struct.unpack('!i',pyz[8:12])[0]:]))
records = {}
for name,(kind,offset,size) in toc.items():
    if name.split('.')[0] not in ('core','providers','ui') or kind not in (0,1):
        continue
    target = root/'engine'/Path(*name.split('.'))
    target = target/'__init__.pyc' if kind==1 else target.with_suffix('.pyc')
    target.parent.mkdir(parents=True,exist_ok=True)
    code = zlib.decompress(pyz[offset:offset+size])
    target.write_bytes(pyz[4:8]+bytes(12)+code)
    records[name] = hashlib.sha256(code).hexdigest()
shutil.copytree(source/'_internal/core/data',root/'engine/core/data',dirs_exist_ok=True)
for name in ('studio_app.py','theme.py','studio_qa.py'):
    shutil.copy2(workspace/'studio_20261106'/name,root/'studio'/name)
shutil.copytree(workspace/'studio_20261106/assets',root/'studio/assets',dirs_exist_ok=True)
# Mac branding and paths; leave the Windows release untouched.
p=root/'studio/studio_app.py'
s=p.read_text(encoding='utf-8').replace('STUDIO 2.0  /  WINDOWS','STUDIO 2.0  /  macOS')
s=s.replace('Windows 64-bit •','macOS · Apple Silicon •').replace('Ctrl+S','⌘S')
s=s.replace("str(Path(sys.executable).parent/'qa-profile'/str(os.getpid()))","str(Path(os.environ['BROLL_QA_DIR'])/'profile')")
p.write_text(s,encoding='utf-8')
p=root/'studio/theme.py'
s=p.read_text(encoding='utf-8').replace('QFont("Segoe UI", 10)','QFont("Helvetica Neue", 12)')
# Offscreen macOS font registration must use Mac system fonts, not Windows paths.
start=s.index("    if app.platformName() == 'offscreen':")
end=s.index('    app.setStyle("Fusion")',start)
s=s[:start]+s[end:]
s=s.replace("font-family: 'Segoe UI'","font-family: 'Helvetica Neue'").replace('font-family: Consolas','font-family: Menlo')
p.write_text(s,encoding='utf-8')
p=root/'studio/studio_qa.py'
s=p.read_text(encoding='utf-8').replace('import json','import json\nimport os',1)
s=s.replace("folder=Path(sys.executable).parent/'qa'","folder=Path(os.environ['BROLL_QA_DIR'])")
p.write_text(s,encoding='utf-8')
(root/'engine-manifest.json').write_text(json.dumps({'source_exe_sha256':hashlib.sha256((source/'BRollFinder.exe').read_bytes()).hexdigest(),'python_magic':pyz[4:8].hex(),'modules':records},indent=2),encoding='utf-8')
print(f'Prepared {len(records)} original application modules, Studio UI and resources.')
