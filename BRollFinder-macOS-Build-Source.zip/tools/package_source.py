"""Package only build inputs; never include profiles, downloads, or QA projects."""
import hashlib
import json
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
target = ROOT.parent / 'dist' / 'BRollFinder-macOS-Build-Source.zip'
target.parent.mkdir(exist_ok=True)
files = [ROOT / name for name in (
    '.gitignore', 'README.txt', 'main_macos.py', 'engine-manifest.json',
    'runtime-sources.json', 'requirements-macos.txt', 'requirements-lock.txt',
)]
for directory in ('.github', 'assets', 'engine', 'studio', 'tools'):
    files.extend(p for p in (ROOT / directory).rglob('*')
                 if p.is_file() and '__pycache__' not in p.parts)
with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for file in sorted(files):
        archive.write(file, file.relative_to(ROOT).as_posix())
with zipfile.ZipFile(target) as archive:
    assert archive.testzip() is None
print(json.dumps({'file': str(target), 'files': len(files),
                  'bytes': target.stat().st_size,
                  'sha256': hashlib.sha256(target.read_bytes()).hexdigest()}, indent=2))
