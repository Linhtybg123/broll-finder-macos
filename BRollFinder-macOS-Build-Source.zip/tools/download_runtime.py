import hashlib
import json
import urllib.request
from pathlib import Path
root=Path(__file__).resolve().parent.parent
destination=root/'downloads'
destination.mkdir(exist_ok=True)
for name,info in json.loads((root/'runtime-sources.json').read_text()).items():
    path=destination/info['filename']
    if not path.exists() or hashlib.sha256(path.read_bytes()).hexdigest()!=info['sha256']:
        print('Downloading',name,flush=True)
        request=urllib.request.Request(info['url'],headers={'User-Agent':'BRollFinder-Studio-build'})
        with urllib.request.urlopen(request,timeout=120) as response, path.open('wb') as output:
            while chunk:=response.read(1024*1024):
                output.write(chunk)
    if hashlib.sha256(path.read_bytes()).hexdigest()!=info['sha256']:
        raise RuntimeError(f'SHA-256 mismatch: {name}')
    print(name,'SHA-256 verified',path.stat().st_size,flush=True)
