"""Execute tests on a real macOS ARM64 host; never marks a Windows run as passed."""
import argparse
import json
import os
import platform
import subprocess
import sys
import time
from pathlib import Path

ROOT=Path(__file__).resolve().parent.parent

def main():
    if sys.platform!='darwin' or platform.machine()!='arm64':
        raise SystemExit('Native validation requires a macOS Apple Silicon runner. No tests executed.')
    parser=argparse.ArgumentParser()
    parser.add_argument('--app',type=Path,required=True)
    args=parser.parse_args()
    app=args.app.resolve()
    launcher=app/'Contents/MacOS/BRollFinder'
    report_dir=ROOT/'qa'/('native-'+str(int(time.time())))
    report_dir.mkdir(parents=True)
    env=dict(os.environ,BROLL_QA_DIR=str(report_dir),PATH='/usr/bin:/bin:/usr/sbin:/sbin')
    env.pop('QT_QPA_PLATFORM',None)
    env['QT_QPA_PLATFORM']='cocoa'
    executable=app/'Contents/Resources/runtime/python/bin/python3.14'
    machine=subprocess.check_output([str(executable),'-c','import platform; print(platform.machine())'],env=env,text=True).strip()
    assert machine=='arm64',machine
    try:
        for name,flags in (('dependencies',['--selftest','--offline','--quiet']),('ui-pipeline',['--studio-qa'])):
            with (report_dir/(name+'.log')).open('w',encoding='utf-8') as log:
                subprocess.run([str(launcher),*flags],cwd=str(report_dir),env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180,check=True)
        report=json.loads((report_dir/'report.json').read_text())
        assert report['ok'] and report['analyze_worker'] and report['manifest_reload_and_keyword_edit']
        assert report['voice_samples_preserved']==128000
        assert (report_dir/'project.png').is_file()
        result={'status':'PASSED_ON_MACOS','platform':platform.platform(),'architecture':machine,
                'app':str(app),'evidence':str(report_dir),'checks':['runtime','ffmpeg','deno','whisper process','native Cocoa UI','analysis worker','audio samples','manifest reload']}
        (ROOT/'qa/native-validation.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
        print(json.dumps(result,indent=2))
    except Exception as error:
        (ROOT/'qa/native-validation.json').write_text(json.dumps({'status':'FAILED_ON_MACOS','error':str(error),'evidence':str(report_dir)},indent=2),encoding='utf-8')
        raise

if __name__=='__main__':
    main()
