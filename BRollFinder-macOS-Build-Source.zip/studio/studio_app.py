"""Studio presentation layer; original UP processing and signal connections stay intact."""
import os
import sys
from pathlib import Path
from shiboken6 import isValid
from PySide6.QtCore import QEvent, QObject, QSize, Qt, QTimer
from PySide6.QtGui import QIcon, QKeySequence, QShortcut
from PySide6.QtWidgets import (QApplication, QButtonGroup, QComboBox, QFileDialog,
    QFormLayout, QFrame, QGridLayout, QGroupBox, QHBoxLayout, QHeaderView, QLabel,
    QMenu, QMessageBox, QPushButton, QScrollArea, QSizePolicy, QStackedWidget,
    QTabWidget, QToolButton, QVBoxLayout, QWidget)
from theme import ASSETS, apply_theme, app_icon


def label(text, style='', wrap=False):
    w = QLabel(text)
    w.setObjectName(style)
    w.setWordWrap(wrap)
    return w


def button(text, slot, role='', glyph=''):
    b = QPushButton(text)
    if role:
        b.setProperty('role', role)
    if glyph:
        b.setIcon(QIcon(str(ASSETS / (glyph + '.png'))))
    b.clicked.connect(slot)
    return b


def card(title, subtitle=''):
    w = QFrame()
    w.setObjectName('card')
    box = QVBoxLayout(w)
    box.setContentsMargins(18, 16, 18, 16)
    box.setSpacing(10)
    box.addWidget(label(title, 'cardTitle'))
    if subtitle:
        box.addWidget(label(subtitle, 'muted', True))
    return w, box


def scroll_page(w):
    area = QScrollArea()
    area.setWidgetResizable(True)
    area.setFrameShape(QFrame.NoFrame)
    area.setWidget(w)
    return area


class EmptyTable(QObject):
    def __init__(self, table, youtube=False):
        super().__init__(table)
        self.table = table
        self.panel = QWidget(table.viewport())
        self.panel.setAttribute(Qt.WA_TransparentForMouseEvents)
        self.panel.setObjectName('emptyState')
        box = QVBoxLayout(self.panel)
        box.setSpacing(8)
        box.addStretch()
        art = QLabel()
        art.setAlignment(Qt.AlignCenter)
        art.setPixmap(QIcon(str(ASSETS / ('youtube.png' if youtube else 'film.png'))).pixmap(36,36))
        box.addWidget(art)
        title = 'Thư viện video của bạn bắt đầu tại đây' if youtube else 'Sẵn sàng cho câu chuyện tiếp theo'
        detail = 'Dán link hoặc chọn kênh, rồi lấy danh sách video.' if youtube else 'Thêm kịch bản và voice, sau đó nhấn Phân tích để tạo danh sách cảnh.'
        for text, style in ((title,'emptyTitle'), (detail,'muted')):
            line = label(text,style,True)
            line.setAlignment(Qt.AlignCenter)
            box.addWidget(line)
        box.addStretch()
        table.viewport().installEventFilter(self)
        for signal in (table.model().rowsInserted,table.model().rowsRemoved,table.model().modelReset):
            signal.connect(self.refresh)
        self.refresh()

    def refresh(self,*args):
        if not isValid(self.table) or not isValid(self.panel):
            return
        self.panel.setGeometry(self.table.viewport().rect())
        self.panel.setVisible(self.table.rowCount()==0)

    def eventFilter(self,obj,event):
        if event.type() in (QEvent.Resize,QEvent.Show):
            self.refresh()
        return False


def prepare_table(table,youtube=False):
    table.setShowGrid(False)
    table.setAlternatingRowColors(True)
    table.verticalHeader().hide()
    table.verticalHeader().setMinimumSectionSize(48)
    table.setMinimumHeight(210)
    table.horizontalHeader().setMinimumSectionSize(32)
    table.horizontalHeader().setSectionResizeMode(2,QHeaderView.Stretch)
    widths = {0:32,1:42,3:112,4:100,5:80,6:90,7:75,8:80,9:78,10:155} if youtube else {0:32,1:42,3:80,4:200,5:165,6:145}
    for col,width in widths.items():
        if col<table.columnCount():
            table.setColumnWidth(col,width)
    if not youtube:
        for col,text in ((0,''),(2,'NỘI DUNG'),(3,'GIÂY'),(4,'TỪ KHÓA'),(5,'MEDIA'),(6,'TRẠNG THÁI')):
            table.horizontalHeaderItem(col).setText(text)
    table._empty_state=EmptyTable(table,youtube)


def file_row(form,title,edit,browse):
    edit.setSizePolicy(QSizePolicy.Ignored,QSizePolicy.Fixed)
    edit.setMinimumWidth(70)
    row=QHBoxLayout()
    row.setSpacing(8)
    row.addWidget(edit,1)
    row.addWidget(button('Chọn',browse,glyph='folder'))
    form.addRow(title,row)


def add_log(box,owner):
    row=QHBoxLayout()
    owner.status_lbl.setObjectName('muted')
    owner.status_lbl.setWordWrap(True)
    row.addWidget(owner.status_lbl,1)
    toggle=QToolButton()
    toggle.setText('Nhật ký xử lý')
    toggle.setCheckable(True)
    toggle.setObjectName('logToggle')
    toggle.toggled.connect(owner.log_view.setVisible)
    row.addWidget(toggle)
    box.addLayout(row)
    owner.progress.setTextVisible(False)
    box.addWidget(owner.progress)
    owner.log_view.setMaximumHeight(105)
    owner.log_view.setMinimumHeight(85)
    owner.log_view.setMaximumBlockCount(1500)
    box.addWidget(owner.log_view)
    owner.log_view.hide()


class StudioMixin:
    def build_studio(self):
        self.setWindowTitle('B-Roll Finder Studio')
        self.setWindowIcon(app_icon())
        self.resize(1440,940)
        self.setMinimumSize(1100,740)
        self.original_tabs=self.takeCentralWidget()
        self.original_tabs.hide()
        self.original_tabs.setParent(self)
        self.original_settings=self.original_tabs.widget(2)
        self.original_settings.setParent(self)
        self.original_settings.hide()
        shell=QWidget()
        shell.setObjectName('shell')
        horizontal=QHBoxLayout(shell)
        horizontal.setContentsMargins(0,0,0,0)
        horizontal.setSpacing(0)
        rail=QFrame()
        rail.setObjectName('sidebar')
        rail.setFixedWidth(212)
        side=QVBoxLayout(rail)
        side.setContentsMargins(16,28,16,20)
        side.setSpacing(8)
        identity=QHBoxLayout()
        mark=QLabel()
        mark.setPixmap(app_icon().pixmap(40,40))
        identity.addWidget(mark)
        names=QVBoxLayout()
        names.setSpacing(0)
        names.addWidget(label('B-Roll Finder','brandName'))
        names.addWidget(label('STUDIO','eyebrow'))
        identity.addLayout(names)
        identity.addStretch()
        side.addLayout(identity)
        side.addSpacing(36)
        side.addWidget(label('KHÔNG GIAN LÀM VIỆC','eyebrow'))
        side.addSpacing(4)
        self.nav_group=QButtonGroup(self)
        self.nav_group.setExclusive(True)
        self.nav_buttons=[]
        for i,(name,glyph) in enumerate((('Dự án B-roll','film'),('YouTube Studio','youtube'),('Nguồn && cài đặt','settings'),('Hướng dẫn','help'))):
            nav=button(name,lambda checked=False,index=i:self.navigate(index),glyph=glyph)
            nav.setObjectName('navButton')
            nav.setCheckable(True)
            nav.setIconSize(QSize(20,20))
            self.nav_group.addButton(nav,i)
            self.nav_buttons.append(nav)
            side.addWidget(nav)
        side.addStretch()
        tip,tip_box=card('Từ ý tưởng đến khung hình')
        tip.setObjectName('sideTip')
        tip_box.addWidget(label('Kịch bản. Voice. Footage.\nMột không gian sáng tạo.','muted',True))
        side.addWidget(tip)
        side.addSpacing(16)
        side.addWidget(label('STUDIO 2.0  /  macOS','eyebrow'))
        horizontal.addWidget(rail)
        content=QVBoxLayout()
        content.setContentsMargins(28,26,28,18)
        content.setSpacing(20)
        header=QHBoxLayout()
        titles=QVBoxLayout()
        titles.setSpacing(6)
        self.page_title=label('','pageTitle')
        self.page_description=label('','muted',True)
        titles.addWidget(label('B-ROLL FINDER  /  CREATIVE WORKSPACE','eyebrow'))
        titles.addWidget(self.page_title)
        titles.addWidget(self.page_description)
        header.addLayout(titles,1)
        self.ready_badge=label('●  Sẵn sàng','badge')
        header.addWidget(self.ready_badge,0,Qt.AlignTop)
        content.addLayout(header)
        self.pages=QStackedWidget()
        self.pages.addWidget(scroll_page(self.build_project()))
        self.pages.addWidget(scroll_page(self.build_youtube()))
        self.pages.addWidget(self.build_settings())
        self.pages.addWidget(scroll_page(self.build_help()))
        content.addWidget(self.pages,1)
        horizontal.addLayout(content,1)
        self.setCentralWidget(shell)
        self.navigate(0)
        self.save_shortcut=QShortcut(QKeySequence.Save,self)
        self.save_shortcut.activated.connect(self.save_studio_settings)
        self.health_timer=QTimer(self)
        self.health_timer.timeout.connect(self.refresh_activity)
        self.health_timer.start(700)

    def navigate(self,index):
        self.pages.setCurrentIndex(index)
        self.nav_buttons[index].setChecked(True)
        title,description=(('Dự án B-roll','Biến kịch bản và voice thành những cảnh quay phù hợp.'),
            ('YouTube Studio','Quản lý video, transcript và bình luận trong cùng một quy trình.'),
            ('Nguồn & cài đặt','Kết nối thư viện media và cá nhân hóa cách xử lý của bạn.'),
            ('Bắt đầu cùng Studio','Mọi thứ bạn cần để tạo dự án B-roll đầu tiên.'))[index]
        self.page_title.setText(title)
        self.page_description.setText(description)

    def refresh_activity(self):
        busy=any(w is not None and w.isRunning() for w in (self.worker,self.ytdl_tab.worker))
        self.ready_badge.setText('●  Đang xử lý' if busy else '●  Sẵn sàng')

    def pick_file(self,edit,kind):
        if kind=='folder':
            selected=QFileDialog.getExistingDirectory(self,'Chọn thư mục xuất',edit.text())
        else:
            filters='Kịch bản (*.txt *.docx *.md);;Tất cả (*.*)' if kind=='script' else 'Audio (*.wav *.mp3 *.m4a *.flac *.ogg);;Tất cả (*.*)'
            selected,_=QFileDialog.getOpenFileName(self,'Chọn kịch bản' if kind=='script' else 'Chọn voice',edit.text(),filters)
        if selected:
            edit.setText(selected)
            if kind=='voice' and not self.out_edit.text():
                self.out_edit.setText(str(Path(selected).parent/'broll_output'))

    def build_project(self):
        for combo,names in ((self.lang_combo,('Tự động','Tiếng Anh','Tiếng Việt')),
                            (self.split_combo,('Cụm từ','Câu')),
                            (self.align_combo,('Whisper','Ước lượng')),
                            (self.media_combo,('Video → ảnh','Chỉ video','Chỉ ảnh'))):
            for i,name in enumerate(names):
                if i<combo.count():
                    combo.setItemData(i,combo.itemText(i),Qt.ToolTipRole)
                    combo.setItemText(i,name)
        self.align_combo.setToolTip('Whisper: căn theo giọng đọc. Ước lượng: xử lý nhanh, không cần tải model.')
        page=QWidget()
        root=QVBoxLayout(page)
        root.setContentsMargins(0,0,10,0)
        root.setSpacing(16)
        top=QHBoxLayout()
        top.setSpacing(16)
        inputs,box=card('01  /  Tệp dự án','Thêm nội dung và chọn nơi lưu kết quả.')
        form=QFormLayout()
        form.setVerticalSpacing(10)
        for name,edit,kind,hint in (('Kịch bản',self.script_edit,'script','Chọn file .txt, .docx hoặc .md'),('Voice',self.voice_edit,'voice','Chọn bản thu .wav, .mp3 hoặc .m4a'),('Lưu tại',self.out_edit,'folder','Thư mục chứa voice, footage và manifest')):
            edit.setPlaceholderText(hint)
            file_row(form,name,edit,lambda checked=False,e=edit,k=kind:self.pick_file(e,k))
        box.addLayout(form)
        top.addWidget(inputs,3)
        options,box=card('02  /  Cách xử lý','Tinh chỉnh nhịp dựng của dự án.')
        grid=QGridLayout()
        grid.setHorizontalSpacing(12)
        grid.setVerticalSpacing(6)
        for i,(name,combo) in enumerate((('Ngôn ngữ',self.lang_combo),('Tách kịch bản',self.split_combo),('Căn chỉnh voice',self.align_combo),('Loại media',self.media_combo))):
            combo.setSizePolicy(QSizePolicy.Ignored,QSizePolicy.Fixed)
            combo.setMinimumWidth(90)
            grid.addWidget(label(name,'muted'),(i//2)*2,i%2)
            grid.addWidget(combo,(i//2)*2+1,i%2)
            grid.setColumnStretch(i%2,1)
        box.addLayout(grid)
        top.addWidget(options,2)
        root.addLayout(top)
        actions=QHBoxLayout()
        for name,b in (('1. Phân tích',self.btn_analyze),('2. Tìm media',self.btn_search),('3. Tải về',self.btn_download)):
            b.setText(name)
            actions.addWidget(b)
        self.btn_all.setText('Chạy tất cả')
        self.btn_all.setIcon(QIcon(str(ASSETS/'play.png')))
        self.btn_all.setProperty('role','primary')
        actions.addWidget(self.btn_all)
        self.btn_cancel.setProperty('role','danger')
        actions.addWidget(self.btn_cancel)
        actions.addStretch()
        self.btn_load.setText('Mở dự án')
        self.btn_open_out.setText('Thư mục xuất')
        actions.addWidget(self.btn_load)
        actions.addWidget(self.btn_open_out)
        root.addLayout(actions)
        results,box=card('Danh sách cảnh')
        filters=QHBoxLayout()
        filters.addWidget(button('Chọn tất cả',lambda:self.select_where(lambda item:True)))
        filters.addWidget(button('Bỏ chọn',lambda:self.select_where(lambda item:False)))
        filters.addStretch()
        self.count_lbl.setObjectName('muted')
        filters.addWidget(self.count_lbl)
        filters.addWidget(self.filter_combo)
        box.addLayout(filters)
        prepare_table(self.table)
        box.addWidget(self.table,1)
        utilities=QHBoxLayout()
        utilities.addWidget(button('Nghe voice',self.on_play,glyph='play'))
        utilities.addWidget(button('Đổi media',self.on_choose))
        menu_button=QToolButton()
        menu_button.setText('Thao tác với dòng đã chọn')
        menu_button.setPopupMode(QToolButton.InstantPopup)
        menu=QMenu(menu_button)
        for name,slot in (('Tìm lại media',self.on_research_rows),('Tải lại media',self.on_redownload_rows),('Tìm và tải media',self.on_research_download_rows),('Tìm và cắt từ YouTube',self.on_youtube_rows),('Tạo lại từ khóa',self.on_regen_keywords),('Tạo từ khóa, tìm và tải',self.on_regen_all)):
            menu.addAction(name,slot)
        menu_button.setMenu(menu)
        utilities.addWidget(menu_button)
        utilities.addStretch()
        self.btn_retry.setText('Tìm && tải phần còn thiếu')
        utilities.addWidget(self.btn_retry)
        box.addLayout(utilities)
        root.addWidget(results,1)
        add_log(root,self)
        return page

    def build_youtube(self):
        yt=self.ytdl_tab
        page=QWidget()
        root=QVBoxLayout(page)
        root.setContentsMargins(0,0,10,0)
        root.setSpacing(14)
        top=QHBoxLayout()
        top.setSpacing(16)
        source,box=card('01  /  Nguồn video')
        yt.src_tabs.setMinimumHeight(215)
        yt.src_tabs.setMaximumHeight(255)
        yt.src_tabs.setSizePolicy(QSizePolicy.Ignored,QSizePolicy.Preferred)
        for note in yt.src_tabs.findChildren(QLabel):
            if len(note.text())>65:
                note.setWordWrap(True)
                note.setSizePolicy(QSizePolicy.Ignored,QSizePolicy.Preferred)
        yt.links_edit.setPlaceholderText('Dán link video, Shorts hoặc playlist…\nMỗi link trên một dòng.')
        yt.links_edit.setObjectName('linksEditor')
        yt.links_edit.setMinimumHeight(60)
        yt.mode_hint.setObjectName('muted')
        yt.mode_hint.setWordWrap(True)
        for combo in (yt.ch_edit,yt.mode_combo,yt.tab_combo):
            combo.setSizePolicy(QSizePolicy.Ignored,QSizePolicy.Fixed)
        box.addWidget(yt.src_tabs)
        top.addWidget(source,1)
        options,box=card('02  /  Thiết lập tải xuống')
        form=QFormLayout()
        file_row(form,'Lưu tại',yt.out_edit,yt._pick_out)
        yt.out_edit.setPlaceholderText('Chọn thư mục lưu')
        box.addLayout(form)
        self.yt_options=QTabWidget()
        for name in ('Video','Transcript','Bình luận'):
            self.yt_options.addTab(QWidget(),name)
        video=QVBoxLayout(self.yt_options.widget(0))
        quality=QHBoxLayout()
        quality.addWidget(yt.quality_combo,1)
        yt.cb_h264.setText('Ưu tiên H.264')
        quality.addWidget(yt.cb_h264)
        video.addLayout(quality)
        checks=QGridLayout()
        for i,(b,text) in enumerate(((yt.cb_subs,'Phụ đề vi / en'),(yt.cb_thumb,'Thumbnail'),(yt.cb_chfolder,'Thư mục theo kênh'),(yt.cb_number,'Đánh số tên file'),(yt.cb_skip,'Bỏ qua video đã tải'))):
            b.setText(text)
            checks.addWidget(b,i//2,i%2)
        video.addLayout(checks)
        video.addStretch()
        transcript=QFormLayout(self.yt_options.widget(1))
        for name,field in (('Ngôn ngữ',yt.t_lang),('Định dạng',yt.t_fmt),('Cách lưu',yt.t_save)):
            field.setSizePolicy(QSizePolicy.Ignored,QSizePolicy.Fixed)
            transcript.addRow(name,field)
        comments=QGridLayout(self.yt_options.widget(2))
        for i,(name,field) in enumerate((('Bình luận/video',yt.c_max),('Trả lời/bình luận',yt.c_replies),('Sắp xếp',yt.c_sort),('Định dạng',yt.c_fmt),('Cách lưu',yt.c_save))):
            field.setSizePolicy(QSizePolicy.Ignored,QSizePolicy.Fixed)
            comments.addWidget(label(name,'muted'),(i//3)*2,i%3)
            comments.addWidget(field,(i//3)*2+1,i%3)
            comments.setColumnStretch(i%3,1)
        box.addWidget(self.yt_options)
        top.addWidget(options,1)
        root.addLayout(top)
        actions=QHBoxLayout()
        for name,b in (('1. Lấy danh sách',yt.btn_list),('2. Tải video',yt.btn_dl),('Lấy danh sách && tải',yt.btn_both),('Transcript',yt.btn_tr),('Bình luận',yt.btn_cm),('Hủy',yt.btn_cancel)):
            b.setText(name)
            actions.addWidget(b)
        yt.btn_both.setProperty('role','primary')
        yt.btn_cancel.setProperty('role','danger')
        actions.addStretch()
        root.addLayout(actions)
        results,box=card('Thư viện video')
        utilities=QHBoxLayout()
        for name,slot in (('Chọn tất cả',lambda:yt._check_all(True)),('Bỏ chọn',lambda:yt._check_all(False)),('Xuất CSV',yt._export_csv),('Mở thư mục',yt._open_out)):
            utilities.addWidget(button(name,slot))
        utilities.addStretch()
        yt.count_lbl.setObjectName('muted')
        utilities.addWidget(yt.count_lbl)
        box.addLayout(utilities)
        prepare_table(yt.table,True)
        box.addWidget(yt.table,1)
        root.addWidget(results,1)
        add_log(root,yt)
        root.addWidget(label('Chỉ tải video bạn có quyền sử dụng. Nhấp đúp một dòng để mở video gốc.','muted',True))
        return page

    def build_settings(self):
        page=QWidget()
        root=QVBoxLayout(page)
        root.setContentsMargins(0,0,0,0)
        root.setSpacing(16)
        self.settings_tabs=QTabWidget()
        sections=[]
        for title in ('Thư viện media','YouTube','Từ khóa && xử lý'):
            body=QWidget()
            box=QVBoxLayout(body)
            box.setContentsMargins(0,12,12,12)
            box.setSpacing(16)
            self.settings_tabs.addTab(scroll_page(body),title)
            sections.append(box)
        for group in self.original_settings.findChildren(QGroupBox):
            title=group.title()
            section=1 if 'YouTube' in title else 2 if ('khóa' in title or 'Tuỳ' in title or 'Tùy' in title) else 0
            if 'YouTube —' in title:
                group.setTitle('YouTube / Tìm footage & cắt đoạn')
            sections[section].addWidget(group)
            form=group.layout()
            if isinstance(form,QFormLayout):
                form.setFieldGrowthPolicy(QFormLayout.AllNonFixedFieldsGrow)
                for row in range(form.rowCount()):
                    item=form.itemAt(row,QFormLayout.LabelRole)
                    if item and isinstance(item.widget(),QLabel):
                        item.widget().setMinimumWidth(215)
                        item.widget().setMaximumWidth(240)
                        item.widget().setWordWrap(True)
            for field in group.findChildren(QComboBox):
                field.setSizePolicy(QSizePolicy.Ignored,QSizePolicy.Fixed)
                field.setMinimumWidth(100)
            for note in group.findChildren(QLabel):
                if len(note.text())>90:
                    note.setWordWrap(True)
                    note.setMinimumWidth(0)
                    note.setSizePolicy(QSizePolicy.Ignored,QSizePolicy.Preferred)
        self.cb_translate.setText('Dịch từ khóa tiếng Việt sang tiếng Anh khi tìm footage')
        self.yt_cc.setText('Chỉ lấy video Creative Commons')
        for box in sections:
            box.addStretch()
        root.addWidget(self.settings_tabs,1)
        footer=QHBoxLayout()
        self.settings_feedback=label('Cấu hình được lưu trên máy của bạn.  •  ⌘S để lưu.','muted',True)
        footer.addWidget(self.settings_feedback,1)
        self.save_settings_button=button('Lưu cài đặt',self.save_studio_settings,'primary')
        self.save_settings_button.setMinimumWidth(150)
        footer.addWidget(self.save_settings_button)
        root.addLayout(footer)
        return page

    def save_studio_settings(self):
        try:
            from core import config
            self._collect_cfg()
            config.save(self.cfg)
            self.settings_feedback.setText('Đã lưu cài đặt thành công.  •  ⌘S để lưu.')
            self.status_lbl.setText('Đã lưu cài đặt.')
        except Exception as exc:
            QMessageBox.warning(self,'Không thể lưu cài đặt',str(exc))

    def build_help(self):
        page=QWidget()
        box=QVBoxLayout(page)
        box.setContentsMargins(0,0,12,0)
        box.setSpacing(16)
        for title,text in (
            ('01  /  Chuẩn bị dự án','Chọn kịch bản .txt hoặc .docx, file voice và thư mục xuất. Chọn Ước lượng để thử nhanh; Whisper phù hợp khi cần căn thời gian theo giọng đọc.'),
            ('02  /  Kết nối nguồn footage','Mở Nguồn & cài đặt để nhập key Pexels, Pixabay hoặc Unsplash. Bật YouTube nếu bạn muốn tìm và cắt thêm video. YouTube Data API là tùy chọn.'),
            ('03  /  Phân tích, tìm kiếm, tải về','Nhấn Chạy tất cả hoặc thực hiện từng bước. Sau phân tích, sửa từ khóa trực tiếp trong bảng. Chọn các dòng để đổi media, tìm lại hoặc tải lại.'),
            ('04  /  Tiếp tục dựng video','Mở Thư mục xuất để lấy voice, media và manifest. Dùng Mở dự án để tiếp tục dự án đã lưu. Trong YouTube Studio, bạn cũng có thể chỉ lấy transcript hoặc bình luận.')):
            panel,body=card(title)
            body.addWidget(label(text,'helpText',True))
            box.addWidget(panel)
        panel,body=card('B-Roll Finder Studio 2.0')
        body.addWidget(label('macOS · Apple Silicon • Bộ xử lý BRollFinder UP ngày 05/11/2026.\nWhisper tải model khi dùng lần đầu. Các nguồn trực tuyến cần Internet và key/cookie khi dịch vụ yêu cầu.','muted',True))
        actions=QHBoxLayout()
        actions.addWidget(button('Tạo dự án',lambda:self.navigate(0),'primary'))
        actions.addWidget(button('Thiết lập nguồn',lambda:self.navigate(2)))
        actions.addStretch()
        body.addLayout(actions)
        box.addWidget(panel)
        box.addStretch()
        return page


def install():
    if any(arg.startswith('--studio-') for arg in sys.argv):
        os.environ['APPDATA']=str(Path(os.environ['BROLL_QA_DIR'])/'profile')
    import ui.main_window as original
    class StudioWindow(StudioMixin,original.MainWindow):
        def __init__(self):
            apply_theme(QApplication.instance())
            super().__init__()
            self.build_studio()
            if '--studio-qa' in sys.argv:
                from studio_qa import run
                QTimer.singleShot(300,lambda:run(self))
    original.MainWindow=StudioWindow
