"""Application identity and a consistent desktop palette."""
from pathlib import Path

from PySide6.QtGui import QColor, QFont, QFontDatabase, QIcon, QPalette

ASSETS = Path(__file__).resolve().parent / "assets"


def app_icon():
    return QIcon(str(ASSETS / "app.ico"))


def apply_theme(app):
    app.setStyle("Fusion")
    app.setFont(QFont("Helvetica Neue", 12))
    app.setApplicationName("B-Roll Finder")
    app.setOrganizationName("BRollFinder")
    app.setWindowIcon(app_icon())
    palette = QPalette()
    for role, color in [(QPalette.Window, "#101116"), (QPalette.WindowText, "#e8e9f0"),
                        (QPalette.Base, "#15171e"), (QPalette.AlternateBase, "#191b24"),
                        (QPalette.Text, "#e8e9f0"), (QPalette.Button, "#22252f"),
                        (QPalette.ButtonText, "#e8e9f0"), (QPalette.Highlight, "#51416f"),
                        (QPalette.HighlightedText, "#ffffff"), (QPalette.PlaceholderText, "#777b8e"),
                        (QPalette.ToolTipBase, "#303342"), (QPalette.ToolTipText, "#ffffff")]:
        palette.setColor(role, QColor(color))
    palette.setColor(QPalette.Disabled, QPalette.Text, QColor("#656879"))
    palette.setColor(QPalette.Disabled, QPalette.ButtonText, QColor("#656879"))
    app.setPalette(palette)
    app.setStyleSheet(STYLE.replace("@ASSETS@", ASSETS.as_posix()))


STYLE = """
QWidget { color: #e8e9f0; }
QMainWindow, QDialog { background: #101116; }
QWidget#brandHeader { background: #181a21; border: 1px solid #30323e; border-radius: 12px; }
QLabel#brandName { font-size: 16px; font-weight: 700; color: #f4f3fc; }
QLabel#muted, QLabel#settingsFeedback { color: #979bab; font-size: 12px; }
QLabel#badge { color: #b9a2fa; background: #28213a; padding: 6px 12px; border-radius: 10px; font-size: 11px; font-weight: 600; }
QTabWidget::pane { border: none; }
QTabBar::tab { background: transparent; color: #9a9daf; padding: 10px 16px; margin: 4px 12px 4px 0; border-bottom: 2px solid transparent; font-weight: 600; }
QTabBar::tab:selected { color: #c0a9ff; border-bottom: 2px solid #ad90ff; }
QTabBar::tab:hover { color: #e8e9f0; background: #232331; }
QGroupBox { background: #191b23; border: 1px solid #30323e; border-radius: 10px; margin-top: 14px; padding: 17px 14px 12px; font-weight: 600; }
QGroupBox::title { subcontrol-origin: margin; left: 16px; padding: 0 7px; color: #c9c7d9; }
QLabel { background: transparent; }
QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox { background: #12141b; border: 1px solid #343744; border-radius: 6px; padding: 6px 9px; min-height: 20px; selection-background-color: #5c497a; }
QLineEdit:focus, QComboBox:focus, QSpinBox:focus, QDoubleSpinBox:focus { border-color: #ad90ff; }
QComboBox { padding-right: 26px; }
QSpinBox, QDoubleSpinBox { padding-right: 26px; }
QSpinBox::up-button, QDoubleSpinBox::up-button { subcontrol-origin: border; subcontrol-position: top right; width: 22px; border: none; }
QSpinBox::down-button, QDoubleSpinBox::down-button { subcontrol-origin: border; subcontrol-position: bottom right; width: 22px; border: none; }
QSpinBox::up-arrow, QDoubleSpinBox::up-arrow { image: url(@ASSETS@/chevron-up.svg); width: 12px; height: 12px; }
QSpinBox::down-arrow, QDoubleSpinBox::down-arrow { image: url(@ASSETS@/chevron.svg); width: 12px; height: 12px; }
QComboBox::drop-down { border: none; width: 24px; }
QComboBox::down-arrow { image: url(@ASSETS@/chevron.svg); width: 16px; height: 16px; }
QComboBox QAbstractItemView { background: #222430; selection-background-color: #51416f; padding: 5px; border: 1px solid #414456; }
QPushButton, QToolButton { background: #242731; border: 1px solid #383b49; border-radius: 6px; padding: 7px 12px; min-height: 19px; font-weight: 600; }
QPushButton:hover, QToolButton:hover { background: #313544; border-color: #747085; }
QPushButton:pressed, QToolButton:pressed { background: #1c1d29; }
QPushButton:disabled, QToolButton:disabled { color: #656878; background: #1b1d26; border-color: #2b2d3a; }
QPushButton[role="primary"] { background: #ad90ff; color: #211632; border: 1px solid #ad90ff; }
QPushButton[role="primary"]:hover { background: #c5afff; }
QPushButton[role="primary"]:disabled { background: #4e4169; color: #a9a0ba; border-color: #4e4169; }
QPushButton[role="danger"] { color: #e8a3ab; }
QToolButton::menu-indicator { image: url(@ASSETS@/chevron.svg); width: 13px; height: 13px; subcontrol-position: right center; right: 7px; }
QToolButton { padding-right: 25px; }
QMenu { background: #222430; border: 1px solid #414456; padding: 5px; }
QMenu::item { padding: 9px 25px; border-radius: 4px; }
QMenu::item:selected { background: #51416f; }
QMenu::separator { background: #383b49; height: 1px; margin: 5px; }
QCheckBox { spacing: 8px; }
QCheckBox::indicator, QTableWidget::indicator { width: 16px; height: 16px; border: 1px solid #575b6e; border-radius: 4px; background: #12141b; }
QCheckBox::indicator:checked, QTableWidget::indicator:checked { background: #ad90ff; border-color: #ad90ff; image: url(@ASSETS@/check.svg); }
QCheckBox::indicator:disabled { background: #2c2e3c; border-color: #383b49; }
QTableWidget, QListWidget { background: #15171e; alternate-background-color: #191b24; border: 1px solid #30323e; border-radius: 8px; gridline-color: #2c2e3c; selection-background-color: #423456; outline: none; }
QTableWidget::item { padding: 7px; border-bottom: 1px solid #292c37; }
QHeaderView::section { background: #20222d; color: #a5a8b9; padding: 10px 7px; border: none; border-right: 1px solid #30323f; font-weight: 600; }
QTableCornerButton::section { background: #20222d; border: none; }
QPlainTextEdit { background: #11131a; border: 1px solid #303342; border-radius: 6px; padding: 8px; color: #a2a6ba; font-family: Menlo; font-size: 12px; }
QProgressBar { background: #30323d; border: none; border-radius: 3px; max-height: 6px; min-height: 6px; }
QProgressBar::chunk { background: #ad90ff; border-radius: 3px; }
QScrollArea { border: none; background: #101116; }
QScrollArea > QWidget > QWidget { background: #101116; }
QScrollBar:vertical { background: transparent; width: 10px; margin: 2px; }
QScrollBar::handle:vertical { background: #444758; min-height: 32px; border-radius: 4px; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical { background: none; }
QScrollBar:horizontal { height: 10px; background: #15171e; }
QScrollBar::handle:horizontal { background: #444758; min-width: 32px; border-radius: 4px; }
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal { width: 0; }
QToolTip { background: #303342; color: #f4f8fc; border: 1px solid #5c5f72; padding: 6px; }
"""

STYLE += """
QWidget#shell { background: #101116; }
QFrame#sidebar { background: #16181f; border-right: 1px solid #292c35; }
QLabel#pageTitle { color: #f2f2f8; font-size: 29px; font-weight: 700; }
QLabel#eyebrow { color: #74788c; font-size: 10px; font-weight: 600; letter-spacing: 1px; }
QLabel#cardTitle { color: #dcdde8; font-size: 13px; font-weight: 600; }
QLabel#emptyTitle { color: #cbcada; font-size: 17px; font-weight: 600; }
QLabel#helpText { color: #b8bbcb; font-size: 14px; }
QFrame#card { background: #191b23; border: 1px solid #30323e; border-radius: 12px; }
QFrame#sideTip { background: #1e1d2b; border: 1px solid #343044; border-radius: 10px; }
QFrame#sideTip QLabel#cardTitle { font-size: 11px; }
QFrame#sideTip QLabel#muted { font-size: 11px; }
QPushButton#navButton { text-align: left; padding: 12px 10px; background: transparent; border: 1px solid transparent; color: #9ea2b4; font-weight: 500; }
QPushButton#navButton:hover { background: #21242f; color: #eeedf8; }
QPushButton#navButton:checked { background: #30283f; border-color: #49395e; color: #d3bfff; }
QPlainTextEdit#linksEditor { font-family: 'Helvetica Neue'; font-size: 13px; color: #d4d6e3; }
QWidget#emptyState { background: #15171e; }
QToolButton#logToggle { background: transparent; border: none; color: #9995af; padding: 4px 8px; }
QProgressBar { max-height: 4px; min-height: 4px; }
QScrollArea, QScrollArea > QWidget > QWidget { background: transparent; }
QPushButton:focus, QToolButton:focus { border: 1px solid #b69cff; }
QTabBar::tab { margin-right: 6px; }
QPushButton[role="danger"]:disabled { color: #656878; background: #1b1d26; border-color: #2b2d3a; }
"""
