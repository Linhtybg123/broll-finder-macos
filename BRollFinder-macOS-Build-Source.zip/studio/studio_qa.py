"""Local-only QA invoked explicitly with --studio-qa, using an isolated config."""
import json
import os
import sys
import traceback
import time
from pathlib import Path
from PySide6.QtWidgets import QApplication
from PySide6.QtCore import QTimer, Qt

def run(w):
    folder=Path(os.environ['BROLL_QA_DIR'])
    folder.mkdir(exist_ok=True)
    report={}
    def complete():
        (folder/'report.json').write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf-8')
        QApplication.instance().exit(0 if report['ok'] else 1)
    try:
        app=QApplication.instance()
        report['pages']=w.pages.count()
        report['settings_groups']=[g.title() for g in w.findChildren(__import__('PySide6.QtWidgets',fromlist=['QGroupBox']).QGroupBox) if g.isVisible()]
        for i,name in enumerate(('project','youtube','settings','help')):
            w.navigate(i)
            app.processEvents()
            w.grab().save(str(folder/(name+'.png')))
        w.navigate(2)
        for i in (1,2):
            w.settings_tabs.setCurrentIndex(i)
            app.processEvents()
            w.grab().save(str(folder/f'settings-{i}.png'))
        w.navigate(1)
        w.ytdl_tab.src_tabs.setCurrentIndex(1)
        for i in (1,2):
            w.yt_options.setCurrentIndex(i)
            app.processEvents()
            w.grab().save(str(folder/f'youtube-{i}.png'))
        w.navigate(0)
        w.resize(1100,740)
        app.processEvents()
        w.grab().save(str(folder/'compact.png'))
        report['api_controls_present']=all(hasattr(w,x) for x in ('yt_api_key','yt_api_mode','yt_cookie_file'))
        report['project_columns']=w.table.columnCount()
        report['youtube_columns']=w.ytdl_tab.table.columnCount()
        w.save_studio_settings()
        from core import config
        report['settings_saved']=(config.config_dir()/'config.json').exists()
        # Run the actual Analyze button and QThread, using synthetic local audio.
        import numpy as np
        import soundfile as sf
        sample=folder/('sample-'+str(int(time.time())))
        sample.mkdir()
        script=sample/'script.txt'
        script.write_text('A camera moves through a green forest. Sunlight shines over the mountains. A river flows beside a quiet village.',encoding='utf-8')
        voice=sample/'voice.wav'
        rate=16000
        sf.write(str(voice),0.1*np.sin(2*np.pi*220*np.arange(8*rate)/rate),rate,subtype='PCM_16')
        w.script_edit.setText(str(script))
        w.voice_edit.setText(str(voice))
        w.out_edit.setText(str(sample/'output'))
        w.align_combo.setCurrentIndex(w.align_combo.findData('estimate'))
        w.lang_combo.setCurrentIndex(w.lang_combo.findData('en'))
        w.cb_translate.setChecked(False)
        w.btn_analyze.click()
        assert w.worker is not None
        started=time.monotonic()
        def finish_test():
            try:
                if w.worker.isRunning():
                    if time.monotonic()-started>45:
                        raise AssertionError('Analyze worker did not complete in 45 seconds')
                    QTimer.singleShot(100,finish_test)
                    return
                app.processEvents()
                assert len(w.project.items)>0
                assert w.table.rowCount()==len(w.project.items)
                assert not w.table._empty_state.panel.isVisible()
                total=0
                for item in w.project.items:
                    total+=sf.info(item.voice_file).frames
                assert total==8*rate, (total,8*rate)
                output=sample/'output'
                assert (output/'manifest.json').is_file()
                assert (output/'manifest.csv').is_file()
                w.table.item(0,4).setText('forest sunlight')
                assert w.project.items[0].keywords=='forest sunlight'
                w.select_where(lambda item:True)
                assert all(w.table.item(i,0).checkState()==Qt.Checked for i in range(w.table.rowCount()))
                w.project.export_manifest()
                from core.pipeline import Project
                restored=Project(w.cfg)
                assert restored.load_manifest(str(output))==len(w.project.items)
                assert restored.items[0].keywords=='forest sunlight'
                from providers.youtube import js_runtimes,ffmpeg_exe
                report['js_runtimes']=js_runtimes()
                report['ffmpeg']=ffmpeg_exe()
                report['analyze_worker']=True
                report['voice_samples_preserved']=total
                report['scene_count']=len(w.project.items)
                report['manifest_reload_and_keyword_edit']=True
                w.resize(1440,940)
                app.processEvents()
                w.grab().save(str(folder/'project-analyzed.png'))
                report['ok']=True
            except Exception:
                report['ok']=False
                report['error']=traceback.format_exc()
            complete()
        QTimer.singleShot(100,finish_test)
        return
    except Exception:
        report['ok']=False
        report['error']=traceback.format_exc()
    complete()
