B-ROLL FINDER STUDIO — macOS / APPLE SILICON

TRẠNG THÁI
Gói .app được lắp ráp trên Windows từ Python và các thư viện macOS ARM64.
Đây là bản THỬ NGHIỆM CHƯA CHẠY TEST TRÊN MACOS, không phải bản phát hành
đã được xác nhận hoạt động. Chưa chạy trên máy macOS CI.

MỤC TIÊU
Apple Silicon M1/M2/M3/M4/M5, macOS 14 trở lên.
Giữ giao diện Studio và 28 mô-đun ứng dụng gốc của BRollFinder UP.
Đã thay runtime Windows bằng Python, Qt, FFmpeg, Deno, Whisper cho macOS.
Cấu hình dùng ~/Library/Application Support/BRollFinder.
Icon ICNS có các kích thước 128, 256, 512 và 1024.

KHÔNG CÓ MÁY MAC
Workflow .github/workflows/macos.yml dùng runner macos-15 (ARM64).
Cần tài khoản GitHub và kho mã có quyền chạy Actions. Workflow chỉ chạy
khi bấm Run workflow / gọi workflow_dispatch, không chạy tự động khi push.
Gói nguồn không chứa API key, cookie hoặc dữ liệu dự án của bạn.
Không đưa mã lên kho công khai để đổi lấy phút CI miễn phí khi chưa có phép.

CÁC BƯỚC CI ĐÃ CHUẨN BỊ
1. Tải Python và Deno đã khóa phiên bản, kiểm tra SHA-256.
2. Tải đúng wheel macOS ARM64/universal2 đã khóa hash.
3. Tạo .app và giữ quyền thực thi, symlink trong ZIP.
4. Chạy ứng dụng với nền tảng Cocoa thực, kiểm tra thư viện và Whisper worker.
5. Thử phân tích, cắt voice, sửa từ khóa, xuất/mở manifest; lưu ảnh các trang.
6. Chỉ khi mọi kiểm tra đạt mới tạo ZIP có nhãn TESTED và DMG.

GÓI THỬ NGHIỆM
output/BRollFinder-Studio-macOS-AppleSilicon-UNTESTED.zip
Giải nén bằng Archive Utility / ditto trên macOS để giữ symlink và quyền file.
Ứng dụng chưa được ký Developer ID hoặc notarize với Apple.
Không vô hiệu hóa Gatekeeper; việc phát hành đã notarize cần Apple Developer ID.

NGUỒN
Engine là bytecode CPython 3.14 lấy nguyên vẹn từ EXE UP được cung cấp.
Mã nguồn giao diện và lớp tương thích macOS nằm trong studio/ và main_macos.py.
Đây không phải tuyên bố đã khôi phục toàn bộ mã nguồn gốc.
engine-manifest.json lưu hash từng mô-đun để đối chiếu.

KIỂM CHỨNG
qa/assembly-report.json: cấu trúc bundle, hash và kiến trúc thư viện, kiểm tra tĩnh.
qa/native-validation.json: chỉ được sinh khi chạy tools/test_macos.py trên Mac.
Không coi kiểm tra tĩnh trên Windows là kiểm thử chạy trên macOS.

Tài liệu tham chiếu:
https://docs.github.com/en/actions/reference/runners/github-hosted-runners
https://github.com/astral-sh/python-build-standalone
https://pypi.org/project/PySide6/6.12.0/
