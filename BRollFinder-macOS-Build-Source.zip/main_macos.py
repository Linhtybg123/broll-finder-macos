"""macOS entry point, with original UP engine and native ARM64 dependencies."""
import faulthandler
import importlib.util
import json
import multiprocessing
import os
import platform
import sys
import traceback
from pathlib import Path

ROOT=Path(__file__).resolve().parent
sys.path[:0]=[str(ROOT/'engine'),str(ROOT/'studio'),str(ROOT)]
SUPPORT=Path.home()/'Library'/'Application Support'/'BRollFinder'

def configure():
    if '--studio-qa' in sys.argv or '--selftest' in sys.argv:
        qa=Path(os.environ.get('BROLL_QA_DIR',str(Path.home()/'Library'/'Logs'/'BRollFinder'/'qa')))
        qa.mkdir(parents=True,exist_ok=True)
        os.environ['BROLL_QA_DIR']=str(qa)
        os.environ['APPDATA']=str(qa/'profile')
    else:
        os.environ['APPDATA']=str(SUPPORT.parent)
    os.environ['PATH']=str(ROOT/'bin')+os.pathsep+os.environ.get('PATH','')
    os.environ.setdefault('KMP_DUPLICATE_LIB_OK','TRUE')
    os.environ.setdefault('HF_HUB_DISABLE_SYMLINKS_WARNING','1')
    engine=json.loads((ROOT/'engine-manifest.json').read_text(encoding='utf-8'))
    if importlib.util.MAGIC_NUMBER.hex()!=engine['python_magic']:
        raise RuntimeError('Python bytecode version does not match the original engine (requires CPython 3.14).')
    # Never rely on Windows ffmpeg names or Finder's minimal PATH.
    import imageio_ffmpeg
    bundled_ffmpeg=imageio_ffmpeg.get_ffmpeg_exe()
    from providers import youtube
    youtube.ffmpeg_exe=lambda:bundled_ffmpeg
    from core import cutter
    import tempfile
    import subprocess
    def decode_audio(path):
        folder=tempfile.mkdtemp(prefix='broll-audio-')
        output=str(Path(folder)/'voice.wav')
        subprocess.run([bundled_ffmpeg,'-y','-i',path,'-c:a','pcm_s16le',output],check=True,
                       stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        return output
    cutter._ffmpeg_to_wav=decode_audio

def main():
    if sys.platform!='darwin' or platform.machine()!='arm64':
        raise RuntimeError('This package requires macOS on Apple Silicon (arm64).')
    configure()
    from core.config import config_dir
    log=(config_dir()/'crash.log').open('a',encoding='utf-8')
    faulthandler.enable(log)
    def report(t,v,tb):
        details=''.join(traceback.format_exception(t,v,tb))
        log.write(details+'\n'); log.flush()
        if '--studio-qa' in sys.argv:
            # Do not wait forever on a modal dialog in CI.
            print(details,file=sys.stderr)
            os._exit(1)
        from PySide6.QtWidgets import QApplication,QMessageBox
        if QApplication.instance():
            QMessageBox.critical(None,'B-Roll Finder',details[-1800:])
    sys.excepthook=report
    if '--selftest' in sys.argv:
        from core.selftest import main as selftest
        return selftest()
    from PySide6.QtWidgets import QApplication
    import studio_app
    studio_app.install()
    from ui.main_window import MainWindow
    app=QApplication(sys.argv)
    app.setApplicationVersion('2.0.0')
    window=MainWindow()
    window.show()
    return app.exec()

if __name__=='__main__':
    multiprocessing.freeze_support()
    sys.exit(main())
